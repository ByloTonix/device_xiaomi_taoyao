/*
 * Copyright (C) 2023 The LineageOS Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#define LOG_TAG "fastcharge@1.0-service.xiaomi_sm8350"

#define FASTCHARGE_DEFAULT_SETTING true
#define FASTCHARGE_PATH "/sys/class/qcom-battery/restrict_chg"

#include "FastCharge.h"
#include <android-base/logging.h>

#include <fstream>
#include <iostream>

namespace vendor {
namespace lineage {
namespace fastcharge {
namespace V1_0 {
namespace implementation {

/*
 * Write value to path and close file.
 */
template <typename T> static void set(const std::string &path, const T &value) {
  std::ofstream file(path);

  if (!file) {
    PLOG(ERROR) << "Failed to open: " << path;
    return;
  }

  LOG(DEBUG) << "write: " << path << " value: " << value;

  file << value << std::endl;

  if (!file) {
    PLOG(ERROR) << "Failed to write: " << path << " value: " << value;
  }
}

template <typename T> static T get(const std::string &path, const T &def) {
  std::ifstream file(path);

  if (!file) {
    PLOG(ERROR) << "Failed to open: " << path;
    return def;
  }

  T result;

  file >> result;

  if (file.fail()) {
    PLOG(ERROR) << "Failed to read: " << path;
    return def;
  } else {
    LOG(DEBUG) << "read: " << path << " value: " << result;
    return result;
  }
}

FastCharge::FastCharge() {}

Return<bool> FastCharge::isEnabled() { return get(FASTCHARGE_PATH, 0) < 1; }

Return<bool> FastCharge::setEnabled(bool enable) {
  bool success = false;
  set(FASTCHARGE_PATH, enable ? 0 : 1);
  if (enable == isEnabled()){
    success = true;
  }
  return success;
}

} // namespace implementation
} // namespace V1_0
} // namespace fastcharge
} // namespace lineage
} // namespace vendor
