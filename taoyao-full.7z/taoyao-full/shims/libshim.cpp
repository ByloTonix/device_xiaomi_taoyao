#include <stdint.h>

namespace android {
    extern "C" void _ZN7android19GraphicBufferSource9configureERKNS_2spINS_16ComponentWrapperEEEiijjj() {}
}
