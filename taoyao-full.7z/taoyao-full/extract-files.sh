#!/bin/bash
#
# Copyright (C) 2016 The CyanogenMod Project
# Copyright (C) 2017-2020 The LineageOS Project
#
# SPDX-License-Identifier: Apache-2.0
#

set -e

DEVICE=taoyao
VENDOR=xiaomi

# Load extract_utils and do some sanity checks
MY_DIR="${BASH_SOURCE%/*}"
if [[ ! -d "${MY_DIR}" ]]; then MY_DIR="${PWD}"; fi

ANDROID_ROOT="${MY_DIR}/../../.."

HELPER="${ANDROID_ROOT}/tools/extract-utils/extract_utils.sh"
if [ ! -f "${HELPER}" ]; then
    echo "Unable to find helper script at ${HELPER}"
    exit 1
fi
source "${HELPER}"

# Default to sanitizing the vendor folder before extraction
CLEAN_VENDOR=true

KANG=
SECTION=

while [ "${#}" -gt 0 ]; do
    case "${1}" in
        -n | --no-cleanup )
                CLEAN_VENDOR=false
                ;;
        -k | --kang )
                KANG="--kang"
                ;;
        -s | --section )
                SECTION="${2}"; shift
                CLEAN_VENDOR=false
                ;;
        * )
                SRC="${1}"
                ;;
    esac
    shift
done

if [ -z "${SRC}" ]; then
    SRC="adb"
fi

function blob_fixup() {
    case "${1}" in
        system_ext/lib64/libwfdnative.so)
            "${PATCHELF}" --remove-needed "android.hidl.base@1.0.so" "${2}"
            ;;
    vendor/lib64/c2.dolby.client.so | vendor/lib64/c2.dolby.store.so | vendor/lib64/libdlbdsservice.so | vendor/lib64/soundfx/libhwdap.so | vendor/lib64/libstagefright_soft_ac4dec.so | vendor/lib64/libstagefright_soft_ddpdec.so | system-ext/lib64/libdovi_omx.so | system-ext/lib/libdovi_omx.so| vendor/lib/mediadrm/libwvdrmengine.so | vendor/lib/mediadrm/libwvdrmengine.so | vendor/lib/c2.dolby.avc.dec.so | vendor/lib/c2.dolby.avc.sec.dec.so | vendor/lib/c2.dolby.egl.so | vendor/lib64/c2.dolby.hevc.dec.so | vendor/lib64/c2.dolby.hevc.enc.so | vendor/lib64/c2.dolby.hevc.sec.dec.so | vendor/lib64/hw/audio.primary.lahaina.so | vendor/lib64/hw/audio.primary.lahaina.so | vendor/lib64/hw/displayfeature.default.so | vendor/lib/hw/displayfeature.default.so | vendor/lib/libdovi.so | vendor/lib64/libmi-stc-HW-modulate.so | vendor/lib64/libmiBrightness.so | vendor/lib64/libqc2audio_hwaudiocodec.so | vendor/lib64/libstagefright_softomx.so | vendor/lib/libstagefright_softomx.so | vendor/lib/libstagefright_softomx_plugin.so | vendor/lib64/soundfx/libdlbvol.so | vendor/lib64/soundfx/libswspatializer.so | vendor/lib64/libcodec2_soft_ddpdec.so | vendor/lib64/libdlbpreg.so | vendor/lib64/libcodec2_soft_ac4dec.so)
        "${PATCHELF}" --replace-needed "libstagefright_foundation.so" "libstagefright_foundation-v33.so" "${2}"
        ;;
    vendor/lib/libcodec2_hidl@1.0.stock.so)
        "${PATCHELF}" --set-soname "libcodec2_hidl@1.0.stock.so" "${2}"
        "${PATCHELF}" --replace-needed "libcodec2_vndk.so" "libcodec2_vndk.stock.so" "${2}"
        ;;
    vendor/lib/libcodec2_vndk.stock.so)
        "${PATCHELF}" --set-soname "libcodec2_vndk.stock.so" "${2}"
            ;;
        vendor/etc/camera/pure*_parameter.xml)
            sed -i 's/=\([0-9]\+\)>/="\1">/g' "${2}"
            ;;
        vendor/etc/media_lahaina/video_system_specs.json \
        |vendor/etc/media_shima_v1/video_system_specs.json \
        |vendor/etc/media_yupik_v1/video_system_specs.json)
            sed -i "/max_retry_alloc_output_timeout/ s/10000/0/" "${2}"
            ;;
        vendor/lib64/hw/camera.xiaomi.so)
            # Before
            # 21 00 80 52     mov        w1,#0x1
            # 29 07 00 94     bl         <EXTERNAL>::android::hardware::configureRpcThr
            # After
            # 21 00 80 52     mov        w1,#0x1
            # 1f 20 03 d5     nop
            sed -i "s/\x21\x00\x80\x52\x29\x07\x00\x94/\x21\x00\x80\x52\x1f\x20\x03\xd5/g" "${2}"
            ;;
        vendor/lib64/hw/camera.qcom.so)
            sed -i "s/\x73\x74\x5F\x6C\x69\x63\x65\x6E\x73\x65\x2E\x6C\x69\x63/\x63\x61\x6D\x65\x72\x61\x5F\x63\x6E\x66\x2E\x74\x78\x74/g" "${2}"
            ;;
        system_ext/lib/libwfdnative.so | system_ext/lib64/libwfdnative.so )
            "${PATCHELF}" --remove-needed "android.hidl.base@1.0.so" "${2}"
            ;;
        vendor/lib64/libwa_sat.so)
            sed -i 's/\/system\/lib64\([^\/]\)/\/vendor\/lib64\1/g' "${2}"
            ;;
        vendor/etc/vintf/manifest/c2_manifest_vendor.xml)
            sed -ni '/ozoaudio/!p' "${2}"
            sed -ni '/dolby/!p' "${2}"
            ;;
        vendor/lib64/android.hardware.secure_element@1.0-impl.so)
            "${PATCHELF}" --remove-needed "android.hidl.base@1.0.so" "${2}"
            ;;
        vendor/etc/camera/taoyao_motiontuning.xml)
            sed -i 's/xml=version/xml\ version/g' "${2}"
            ;;
    esac
}

# Initialize the helper
setup_vendor "${DEVICE}" "${VENDOR}" "${ANDROID_ROOT}" false "${CLEAN_VENDOR}"

extract "${MY_DIR}/proprietary-files.txt" "${SRC}" "${KANG}" --section "${SECTION}"
extract "${MY_DIR}/proprietary-files-recovery.txt" "${SRC}" "${KANG}" --section "${SECTION}"
extract_firmware "${MY_DIR}/proprietary-firmware.txt" "${SRC}"

"${MY_DIR}/setup-makefiles.sh"
